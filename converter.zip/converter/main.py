import asyncio

from telethon.sync import TelegramClient
from opentele.api import UseCurrentSession, CreateNewSession
from opentele.td import TDesktop
import os
from art import *
from colorama import Fore, Style, init
init()

green = Fore.GREEN
red = Fore.RED
yellow = Fore.YELLOW
brigth = Style.BRIGHT
ress = Style.RESET_ALL


print(red + '''Автор - https://t.me/mrx00_11\nКанал автора с софтами - https://t.me/mrx_soft\nLolz автора - https://zelenka.guru/members/5331652/\nEndway автора - https://endway.su/t/''' + ress)
art = text2art('MRX-SOFT', space=2)
print(red + art + ress)

sessions = os.listdir('./from_session_to_tdata/sessions')
tdatas = os.listdir('./from_tdata_to_session/tdatas')

print("""Выберите способ конвертации:
1. From session to TData
2. From TData to session""")
choice_format = input('Введите 1 или 2: ')


async def session_to_tdata(session_path):
    client = TelegramClient(session_path)
    tdesk = await client.ToTDesktop(flag=UseCurrentSession)
    tdesk.SaveTData(f"from_session_to_tdata/tdatas/{os.path.basename(session_path)}/tdata")

async def convert_session_to_tdata():
    for session in sessions:
        try:
            session_path = os.path.join('./from_session_to_tdata/sessions', session)
            await session_to_tdata(session_path)
            print(f'конвертирую session {session} в формат TData')
        except Exception as e:
            print(f'Произошла ошибка - {e}')

    print('Завершил конвертацию')


async def tdata_to_session(tdata_path, session_path):
    tdesk = TDesktop(tdata_path)
    client = await tdesk.ToTelethon(session=session_path, flag=CreateNewSession)

async def convert_tdata_to_session():
    for tdata in tdatas:
        try:
            tdata_path = os.path.join('./from_tdata_to_session/tdatas/', tdata)
            session_path = f"./from_tdata_to_session/sessions/{tdata}.session"
            await tdata_to_session(tdata_path, session_path)
            print(f'конвертирую tdata "{tdata}" в формат session')
        except Exception as e:
            print(f'Произошла ошибка - {e}')

    print('Завершил конвертацию')

async def main():
    if choice_format == '1':
        await convert_session_to_tdata()
    elif choice_format == '2':
        await convert_tdata_to_session()
asyncio.run(main())

